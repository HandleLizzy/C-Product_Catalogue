﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Product_Catalogue
{


    public partial class Form2 : Form
    {
        string connectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C: \Users\lizzy\Documents\My projects\DB\LoginDb.mdf;Integrated Security=True;Connect Timeout=30;");
        public Form2()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txt_firstname.Text == "" || txt_firstname.Text == "")
                MessageBox.Show("please fill mandatory fields");
            else if (txt_firstname.Text != txt_firstname.Text)
                MessageBox.Show("Password do not match");
            else
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    SqlCommand sqlCmd = new SqlCommand("UserAdd", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@FirstName", txt_firstname.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@LastName", txt_firstname.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Contact", txt_firstname.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Password", txt_firstname.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Registration is successfull");


                }
            }

        }
    }
}